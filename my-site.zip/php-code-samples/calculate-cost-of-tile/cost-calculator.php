/* This program calculates the cost of tile to cover a room of a given width and length */
<?php
	$tileShape = 0;
	$tileWidth = 0;
	$roomWidth = 0;
	$roomLength = 0;
?>